/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package mb;

import java.io.Serializable;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
/**
 *
 * @author marcelo
 *
 * @Component("pessoaMB")
@Scope("session")
 *
 */

@Controller("PessoaMB")
@Scope("session")
public class PessoaMB implements Serializable{
    private static final long serialVersionUID = 1L;

    private String nome;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public PessoaMB() {
    }

    public PessoaMB(String nome) {
        this.nome = nome;
    }


   

}
