/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package managedbean;

import classes.Pessoa;

/**
 *
 * @author marcelo
 */

public class IndexManagedBean {

    private Pessoa pessoa;

    public Pessoa getPessoa() {
        return pessoa;
    }

    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }
        
    /** Creates a new instance of IndexManagedBean */
    public IndexManagedBean() {
    
    }



}
