/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package managedbean;

import classes.Pessoa;

/**
 *
 * @author marcelo
 */

public class ExibeManagedBean {

    private Pessoa pessoa;

    public Pessoa getPessoa() {
        return pessoa;
    }

    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }

    

    

    /** Creates a new instance of ExibeManagedBean */
    public ExibeManagedBean() {
        
    }


    public String DoExibePage(){
        return "sucesso";
    }

}
