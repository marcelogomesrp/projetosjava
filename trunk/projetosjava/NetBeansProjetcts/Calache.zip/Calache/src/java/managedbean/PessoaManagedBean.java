/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package managedbean;

import classes.Pessoa;

/**
 *
 * @author marcelo
 */

public class PessoaManagedBean {
    private Pessoa pessoa = null;

    public Pessoa getPessoa() {
        if(this.pessoa == null){
            this.pessoa = new Pessoa();
        }
        return pessoa;
    }

    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }



}
