/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.usp.fmrp.dao.impl;

import br.usp.fmrp.dao.TrabAutorDao;
import br.usp.fmrp.entidades.TrabAutor;

/**
 *
 * @author marcelo
 */
public class TrabAutorDaoImpl  extends DaoGenericoImpl<TrabAutor, Long> implements TrabAutorDao{

}
