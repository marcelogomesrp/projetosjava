/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.usp.fmrp.dao;

import br.usp.fmrp.dao.DaoGenerico;
import br.usp.fmrp.entidades.TrabAutor;

/**
 *
 * @author marcelo
 */
public interface TrabAutorDao extends DaoGenerico<TrabAutor, Long>{

}
