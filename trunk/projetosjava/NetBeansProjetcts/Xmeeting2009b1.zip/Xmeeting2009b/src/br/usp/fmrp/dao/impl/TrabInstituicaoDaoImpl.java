/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.usp.fmrp.dao.impl;

import br.usp.fmrp.dao.TrabInstituicaoDao;
import br.usp.fmrp.entidades.TrabInstituicao;

/**
 *
 * @author marcelo
 */
public class TrabInstituicaoDaoImpl  extends DaoGenericoImpl<TrabInstituicao, Long> implements TrabInstituicaoDao{

}
