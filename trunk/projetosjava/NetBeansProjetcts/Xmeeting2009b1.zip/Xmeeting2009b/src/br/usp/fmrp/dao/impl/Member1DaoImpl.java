/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.usp.fmrp.dao.impl;


import br.usp.fmrp.dao.Member1Dao;
import br.usp.fmrp.entidades.Member1;

/**
 *
 * @author marcelo
 */
public class Member1DaoImpl  extends DaoGenericoImpl<Member1, Integer> implements Member1Dao{

}
 