/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.usp.fmrp.dao.impl;

import br.usp.fmrp.dao.TrabTopicoDao;
import br.usp.fmrp.entidades.TrabTopico;

/**
 *
 * @author marcelo
 */
public class TrabTopicoDaoImpl  extends DaoGenericoImpl<TrabTopico, Long> implements TrabTopicoDao{

}
