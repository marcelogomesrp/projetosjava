/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.usp.fmrp.dao;

import br.usp.fmrp.entidades.Participante;


/**
 *
 * @author marcelo
 */
public interface ParticipanteDao  extends DaoGenerico<Participante, Long>{

}
