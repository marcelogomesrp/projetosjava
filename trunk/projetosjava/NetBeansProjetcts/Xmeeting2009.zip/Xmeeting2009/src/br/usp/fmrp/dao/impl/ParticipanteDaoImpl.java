/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.usp.fmrp.dao.impl;


import br.usp.fmrp.dao.ParticipanteDao;
import br.usp.fmrp.entidades.Participante;

/**
 *
 * @author marcelo
 */
public class ParticipanteDaoImpl  extends DaoGenericoImpl<Participante, Long> implements ParticipanteDao{

}
 