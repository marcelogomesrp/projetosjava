/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.usp.fmrp.dao.impl;

import br.usp.fmrp.dao.TrabGrupoDao;
import br.usp.fmrp.entidades.TrabGrupo;

/**
 *
 * @author marcelo
 */
public class TrabGrupoDaoImpl  extends DaoGenericoImpl<TrabGrupo, Long> implements TrabGrupoDao{

}
