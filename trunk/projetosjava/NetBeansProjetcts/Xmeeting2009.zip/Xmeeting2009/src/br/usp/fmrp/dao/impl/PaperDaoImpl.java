/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.usp.fmrp.dao.impl;

import br.usp.fmrp.dao.PaperDao;
import br.usp.fmrp.entidades.Paper;

/**
 *
 * @author marcelo
 */
public class PaperDaoImpl  extends DaoGenericoImpl<Paper, Long> implements PaperDao{

}
