/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package br.usp.fmrp.dao.impl;

import br.usp.fmrp.dao.TrabalhoDao;
import br.usp.fmrp.entidades.Trabalho;

/**
 *
 * @author marcelo
 */
public class TrabalhoDaoImpl  extends DaoGenericoImpl<Trabalho, Long> implements TrabalhoDao{

}
