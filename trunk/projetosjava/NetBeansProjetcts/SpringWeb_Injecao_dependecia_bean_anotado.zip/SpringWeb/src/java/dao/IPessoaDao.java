/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package dao;

/**
 *
 * @author marcelo
 */
public interface IPessoaDao {

    String getNome();

    void setNome(String nome);

}
