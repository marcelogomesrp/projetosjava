/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package dao;

import org.springframework.stereotype.Service;

/**
 *
 * @author marcelo
 */
@Service
public class PessoaDao implements IPessoaDao  {
    
    
    private String nome;

    public String getNome() {
        this.nome = "Okkkkkkkkkkkkkkkkkkkk";
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }



    

}
