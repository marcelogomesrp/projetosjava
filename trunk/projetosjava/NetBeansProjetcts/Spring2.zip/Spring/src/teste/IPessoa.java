/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package teste;

/**
 *
 * @author marcelo
 */
public interface IPessoa {
    public String getNome();
    public void setNome(String nome);
}
