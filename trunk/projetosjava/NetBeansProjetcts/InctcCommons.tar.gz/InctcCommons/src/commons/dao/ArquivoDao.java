/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package commons.dao;

import negocio.modelo.Arquivo;

/**
 *
 * @author marcelo
 */
public interface ArquivoDao extends DaoGenerico<Arquivo, Long>{
}
