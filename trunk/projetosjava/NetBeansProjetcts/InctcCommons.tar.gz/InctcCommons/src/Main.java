
import commons.dao.ArquivoDao;
import commons.dao.DaoGenerico.MatchMode;
import commons.dao.DataAccessException;
import commons.dao.jpa.ArquivoDaoJPA;
import commons.dao.jpa.HibernateUtil;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import negocio.modelo.Arquivo;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author marcelo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        HibernateUtil.openSession();
        HibernateUtil.currentSession().getTransaction().begin();
        System.out.println("Inicio Teste Persistir Arquivo");
        Arquivo arquivo = new Arquivo();
        arquivo.setId(Long.valueOf(9));
        arquivo.setNome("marcelo7");
        arquivo.setTipo("txt");
        ArquivoDao arquivoDao = new ArquivoDaoJPA();
//        try {
//            arquivoDao.salvar(arquivo);
//        } catch (DataAccessException ex) {
//            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
//        }

        try {
            org.hibernate.criterion.MatchMode hibernateMatchMode = org.hibernate.criterion.MatchMode.ANYWHERE;
            List<Arquivo> arquivos = arquivoDao.listarPorModelo(arquivo, MatchMode.ANYWHERE, "nome", "tipo");
            for(Arquivo arq:arquivos){
                System.out.println("Nome: " + arq.getNome() );
            }
        } catch (DataAccessException ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }

        HibernateUtil.currentSession().getTransaction().commit();
        HibernateUtil.closeCurrentSession();
        System.out.println("Fim  Teste Persistir Arquivo");
    }

}
