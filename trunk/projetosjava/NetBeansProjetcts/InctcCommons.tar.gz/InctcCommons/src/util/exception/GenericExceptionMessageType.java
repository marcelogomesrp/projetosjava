package util.exception;

public enum GenericExceptionMessageType {

	ERROR,
	WARNING,
	INFO
}